from django.apps import AppConfig


class CocktailAppConfig(AppConfig):
    name = 'cocktail_app'
