
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Cocktail, Comment

def index(request):
    return render(request, "index.html")

def register(request):
    return render(request, "register.html")

def registration(request):
    if request.method == "GET":
        return redirect('/register')

    errors = User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/register') 
    else:
        new_user = User.objects.register(request.POST)
        request.session['user_id'] = new_user.id
        messages.success(request, "User successfully registered")
        return redirect('/home')

def signin(request):
    return render(request, "login.html")

def login(request):
    if request.method == "GET":
        return redirect('/')
    if not User.objects.authenticate(request.POST['email'], request.POST['password']):
        messages.error(request, "Invalid Email/Password")
        return redirect('/')
    user = User.objects.get(email=request.POST['email'])
    request.session['user_id'] = user.id
    return redirect('/home')

def logout(request):
    request.session.clear()
    return redirect('/')

def new(request):
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
    }
    return render(request, 'new.html', context)

def profile(request, id):
    context = {
        'user': User.objects.get(id=id)
    }
    return render(request, 'account.html', context)

def edit_profile(request, id):
    context = {
        'user': User.objects.get(id=id),
    }
    return render(request, 'account_update.html', context)

def update_profile(request, id):
    user = User.objects.get(id=id)

    user.first_name = request.POST['first_name']
    user.last_name = request.POST['last_name']
    user.email = request.POST['email']
    user.password = request.POST['password']
    user.save()
    return redirect('/home')

def create(request):
    if request.method == "POST":
        errors = Cocktail.objects.basic_validator(request.POST)
    
        if len(errors) > 0:
        
            for key, value in errors.items():
                messages.error(request, value)
        
            return redirect('/cocktails/new')
        Cocktail.objects.create(
            name = request.POST['name'],
            ingredients = request.POST['ingredients'],
            method = request.POST['method'],
            owner = User.objects.get(id=request.session['user_id'])
        )
        return redirect('/home')

def cocktails(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    print(user)
    context = {
        'user': user,
        'my_cocktails': Cocktail.objects.filter(owner=user),
        'all_cocktails': Cocktail.objects.all()
    }
    return render(request, 'home.html', context)

def edit(request, id):
    context = {
        'cocktail': Cocktail.objects.get(id=id),
    }
    return render(request, 'edit.html', context)

def show(request, id):
    one_cocktail = Cocktail.objects.get(id=id)
    context = {
        "cocktail": one_cocktail,
        "user": User.objects.get(id=request.session['user_id']),
    }
    return render(request, 'cocktail.html', context)

def update(request, id):
    cocktail = Cocktail.objects.get(id=id)

    errors = Cocktail.objects.basic_validator(request.POST)

    if len(errors) > 0:
        
            for key, value in errors.items():
                messages.error(request, value)
        
            return redirect(f'/cocktails/edit/{id}')
    else:
        cocktail.name = request.POST['name']
        cocktail.ingredients = request.POST['ingredients']
        cocktail.method = request.POST['method']
        cocktail.save()
        return redirect('/home')

def delete(request, id):
    cocktail = Cocktail.objects.get(id=id)
    cocktail.delete()
    return redirect('/home')

def post_comment(request, id):
    #create
    poster = User.objects.get(id=request.session['user_id'])
    cocktail = Cocktail.objects.get(id=id)
    Comment.objects.create(comment=request.POST['comment'], poster=poster, cocktail=cocktail)
    return redirect('/cocktails/<int:id>')

def add_like(request, id):
    user_liking = User.objects.get(id=request.session['user_id'])
    liked_cocktail = Cocktail.objects.get(id=id)
    liked_cocktail.user_likes.add(user_liking)
    return redirect('/home')

