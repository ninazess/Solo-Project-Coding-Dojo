from django.urls import path     
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('registration', views.registration),
    path('signin', views.signin),
    path('login', views.login), 
    path('account/<int:id>', views.profile),
    path('account/edit/<int:id>', views.edit_profile),
    path('account/<int:id>/update', views.update_profile),
    path('logout', views.logout),

    path('home', views.cocktails),
    path('cocktails/new', views.new),
    path('cocktails/create', views.create),
    path('cocktails/<int:id>', views.show),
    path('cocktails/edit/<int:id>', views.edit),
    path('cocktails/<int:id>/update', views.update),
    path('cocktails/<int:id>/delete', views.delete),
    path('cocktails/<int:id>/like', views.add_like),
]